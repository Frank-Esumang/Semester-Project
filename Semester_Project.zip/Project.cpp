#include <iostream>
#include <map>
#include <string>

using namespace std;

struct WebPage {
    string title;
    string url;
    string content;
    string date;
};

int main() {
    
    map<string, WebPage> searchEngine;

    
    WebPage page1 {"Page 1", "http://www.google.com", 
	"the process of receiving or giving systematic instruction, especially at a school or university.",
	 "2023-08-10"};
	 
    WebPage page2 {"Page 2", "http://www.google.com",
	 "Programming is the process of writing code to facilitate specific actions in a computer.",
	  "2023-08-13"};
	  
    WebPage page3 {"Page 3", "http://www.google.com",
	 "Information refers to knowledge or facts that have been organized and communicated in a structured and meaningful way.",
	  "2023-08-12"};


    searchEngine["Education","education"] = page1;
    
    searchEngine["Programming","programming"] = page2;
    
    searchEngine["Information","information"] = page3;

    
    string keyword;
    cout << "Enter a keyword to search: ";
    cin >> keyword;

    
    if (searchEngine.find(keyword) != searchEngine.end()) {
        
        WebPage page = searchEngine[keyword];
        cout << "Title: " << page.title << endl;
        cout << "URL: " << page.url << endl;
        cout << "Content: " << page.content << endl;
        cout << "Date: " << page.date << endl;
    }
    else{
    	cout << "No results found for the keyword '" << keyword << "'" << endl;
	}
    	
    	
        
        

    return 0;
}
